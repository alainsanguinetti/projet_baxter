#!/usr/bin/python
# -*- coding: utf8 -*-

# Ce fichier rend le nom "instru.rpr" disponible dans tous les modules

from geometry_msgs.msg import Pose

rpr = Pose ()
