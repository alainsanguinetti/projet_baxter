#!/usr/bin/python
# -*- coding: utf8 -*-

# Ce fichier définit des valeurs utilisées dans plusieurs scripts
# du projet Baxter de Sara, Eder, Alain

DEPLACEMENT = 0.5; # en CM, incrément de chaque déplacement
DEPLACEMENT = DEPLACEMENT * 0.01

BAXTER_USED_LIMB = 'right' # or 'left'
